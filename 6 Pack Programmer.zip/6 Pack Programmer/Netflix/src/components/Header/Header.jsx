import React from 'react';
import '../../app.scss';
import logo from '../../Logo.png';
import { Link } from 'react-router-dom';
import Home from '../Home/Home';
import { ImSearch } from 'react-icons/im';

const Header = () => {
  return (
    <nav className="header">
      <a href="https://www.netflix.com/" target="_blank">
        <img src={logo} alt="Netflix" className="logo" />
      </a>
      <div className="link">
        <Link to="/">Home</Link>
        <Link to="/tvshows">Tv Shows</Link>
        <Link to="/tvshows">Movies</Link>
        <Link to="/tvshows">Recently added</Link>
        <Link to="/">My List</Link>
      </div>
      <ImSearch className='search'/>
    </nav>
  );
};

export default Header;
