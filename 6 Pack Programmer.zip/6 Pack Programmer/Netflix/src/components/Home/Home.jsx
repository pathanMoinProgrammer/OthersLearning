import React, { useEffect, useState } from 'react';
import '../../app.scss';
import './home.scss';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './home.scss';
import { AiOutlinePlus } from 'react-icons/ai';
import { FaPlay } from 'react-icons/fa6';





// This is Website is Not Complete,
// This website need Media Quary for Phone and mobile Users







const apiKey = '0b052442acad0e5c1fbfa0499d29a3a3';
const rest = '&language=en-US&page=1';
const url = 'https://api.themoviedb.org/3/movie';
const genreUrl = 'https://api.themoviedb.org/3/genre/movie/list?';
const imgUrl = 'https://image.tmdb.org/t/p/original';
const page = 1;

const Popular = 'popular';
const upcoming = 'upcoming';
const nowPlaying = 'now_playing';
const topRated = 'top_rated';

// original url : 
// https://api.themoviedb.org/3/movie/550?api_key=0b052442acad0e5c1fbfa0499d29a3a3&language=en-US&page=1

const Card = ({ img }) => (
  <a href={img} target="Blank">
    <img src={img} className="card" alt="Cover" />
  </a>
);

const Row = ({ title, arr = [] }) => {
  return (
    <div className="row">
      <h2 style={{ fontFamily: "'Roboto', sans serif" }}>{title}</h2>
      <div>
        {arr.map((item) => (
          <Card key={item.id} img={`${imgUrl}/${item.poster_path}`} />
        ))}
      </div>
    </div>
  );
};
const Home = () => {
  const [popularMovies, setpopular] = useState([]);
  const [banner, setBanner] = useState([]);
  const [upcomingMovie, setupcomingMovie] = useState([]);
  const [nowPlayingMovie, setnowPlayingMovie] = useState([]);
  const [topRatedMovie, settopRatedMovie] = useState([]);
  const [Genre, setgenre] = useState([]);
  const [loading, setloading] = useState([]);
  const [error, seterror] = useState([]);
  const [count, setCount] = useState(0);

  const plusPage = () => {
    setCount((prev) => prev + 1);
    setloading(true);
  };
  useEffect(() => {
    const fetchPopuler = async () => {
      const {
        data: { results },
      } = await axios.get(
        `${url}/${Popular}?api_key=${apiKey}&language=en-US&page=${page}`,
      );
      setpopular(results);
    };
    const fetchUpcoming = async () => {
      const {
        data: { results },
      } = await axios.get(
        `${url}/${upcoming}?api_key=${apiKey}&language=en-US&page=${page}`,
      );
      setupcomingMovie(results);
    };
    const fetchNowPLaying = async () => {
      const {
        data: { results },
      } = await axios.get(
        `${url}/${nowPlaying}?api_key=${apiKey}&language=en-US&page=${page}`,
      );
      setnowPlayingMovie(results);
    };
    const fetchTopRated = async () => {
      const {
        data: { results },
      } = await axios.get(
        `${url}/${topRated}?api_key=${apiKey}&language=en-US&page=${page}`,
      );
      settopRatedMovie(results);
    };
    const getgenre = async () => {
      const {
        data: { genres },
      } = await axios.get(`${genreUrl}api_key=${apiKey}${rest}`);
      setgenre(genres);
    };
    getgenre();
    fetchUpcoming();
    fetchNowPLaying();
    fetchTopRated();
    fetchPopuler();
  }, [count]);
  return (
    <section className="home">
      <div
        className="banner"
        style={{
          backgroundImage: popularMovies[page]
            ? `url(${`${imgUrl}/${popularMovies[page].backdrop_path}`})`
            : 'white',
        }}
      >
        {popularMovies[page] && (
          <h1 className="h1">{popularMovies[page].original_title}</h1>
        )}
        {popularMovies[page] && (
          <p className="p">{popularMovies[page].overview}</p>
        )}

        <div className="buttonP">
          <button className="play">
            <FaPlay /> Play
          </button>
          <button className="play">
            {' '}
            My List
            <AiOutlinePlus />
          </button>
        </div>
      </div>

      <Row title={'Top Rated'} arr={topRatedMovie} />
      <Row title={'Populer'} arr={popularMovies} />
      <Row title={'upcoming'} arr={upcomingMovie} />
      <Row title={'Now PLaying'} arr={nowPlayingMovie} />

      <button className="nextPage" onClick={plusPage}>
        Next Page
      </button>
      <div className="genreBox">
        {Genre.map((item) => (
          <Link key={item.id} to={`/genre/${item.id}`}>
            {item.name}
          </Link>
        ))}
      </div>
    </section>
  );
};

export default Home;
