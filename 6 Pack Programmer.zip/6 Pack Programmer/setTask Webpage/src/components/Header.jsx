import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { HashLink } from 'react-router-hash-link';

const Header = () => {
  // const param = useParams();
  // console.log(param.name)
  return (
    <>
      <nav> Ready to Manage Your Daily Goal 
        
      </nav>
      <div className="header">
        <HashLink to="/">Home</HashLink>
        {/* <HashLink to="/#about">About</HashLink> */}
        <Link to="/about">About</Link>
        <Link to="/Contact">Contact</Link>
      </div>
    </>
  );
};

export default Header;
