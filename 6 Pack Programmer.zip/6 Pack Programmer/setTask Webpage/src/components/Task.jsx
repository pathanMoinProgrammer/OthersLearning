import React from 'react';

const Task = ({ title, discription, deleteTask, id }) => {
  return (
    <h1 className="task">
      <div>
        <p>title : {title}</p>
        <hr />
        <span className="dis">dis.. : {discription}</span>
      </div>
      <button
        onClick={() => {
          deleteTask(id);
        }}
      >
        -
      </button>
    </h1>
  );
};

export default Task;
