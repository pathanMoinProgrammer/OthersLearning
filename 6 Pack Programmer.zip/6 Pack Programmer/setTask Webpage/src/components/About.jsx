import React from 'react';
import { useNavigate } from 'react-router-dom';


const About = () => {
   const navigation = useNavigate();
  return (
    <div className="about">
      <button
        onClick={() => {
          navigation('/contact');
        }}
      >Go to Contact</button>
    </div>
  );
};

export default About;
