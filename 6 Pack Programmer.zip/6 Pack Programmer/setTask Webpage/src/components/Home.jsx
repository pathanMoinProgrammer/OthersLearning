import React, { useEffect, useState } from 'react';
import Task from './Task';

const Home = () => {
  const [tasks, settasks] = useState([]);
  const [title, settitle] = useState('');

  const [discription, setdiscription] = useState('');

  const submitHandle = (e) => {
    e.preventDefault();

    settasks([
      ...tasks,
      {
        id: Date.now(), // Generate a unique ID for each task
        title: title,
        discription: discription,
      },
    ]);
    // localStorage.getItem('tasks', JSON.stringify(tasks));
  };

  const deleteTask = (id) => {
    let filterAr = tasks.filter((items) => {
      return items.id !== id;
    });
    settasks(filterAr);
  };
  // useEffect(()=>{
  //   localStorage.setItem("tasks", JSON.stringify(tasks));
  // },[tasks])

  return (
    <>
      <div
        className="container"
        style={{
          padding: '1rem',
        }}
      >
        <h1
          style={{
            margin: 'auto',
            marginBottom: '1rem',
            marginTop: '1rem',
            fontFamily: "'Smooch sans', sens serif",
            fontSize: '2.1rem',
            textAlign: 'center',
          }}
        >
          Enter Tasks
        </h1>
        <form onSubmit={submitHandle}>
          <input
            className="title"
            type="text"
            value={title}
            placeholder="Title"
            onChange={(e) => settitle(e.target.value)}
          />
          <textarea
            value={discription}
            placeholder="Description"
            onChange={(e) => setdiscription(e.target.value)}
          ></textarea>
          <button className="submit" type="submit">
            Submit
          </button>
          {tasks.map((task) => (
            <Task
              key={task.id} // Use the unique `id` as the key
              id={task.id}
              index={task.id} // Pass `id` instead of `index`
              title={task.title}
              discription={task.discription}
              deleteTask={deleteTask}
            />
          ))}
        </form>
      </div>
      <br />
    </>
  );
};

export default Home;
