import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@chakra-ui/react';

const Contact = () => {
  const navigation = useNavigate();
  return (
    <div className="contact">
      <button
        onClick={() => {
          navigation('/about');
        }}
      >
        Go to About
      </button>
    </div>
  );
};

export default Contact;
