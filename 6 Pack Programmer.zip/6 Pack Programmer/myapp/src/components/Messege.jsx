import React from 'react';
import { Avatar, HStack, Text } from '@chakra-ui/react';

const Messege = ({ text, url, user = 'other' }) => {
  return (
    <HStack
      maxWidth="80%"
      alignSelf={user === 'me' ? 'flex-end' : 'flex-start'}
      bgColor={'gray.200'}
      paddingX={user === 'me' ? '4' : '3'}
      paddingY={4}
      borderRadius={'5px'}
      whiteSpace="pre-wrap"
      wordBreak="break-word"
      flexShrink={1}   
    >
      {user === 'other' && <Avatar src={url} margin="0 5px 0 0" />}
      <Text>{text}</Text>
      {user === 'me' && <Avatar src={url} margin="0 5px 0 0" />}
    </HStack>
  );
};

export default Messege;
