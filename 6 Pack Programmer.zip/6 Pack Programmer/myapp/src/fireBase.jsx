import { initializeApp } from 'firebase/app';

const firebaseConfig = {
  apiKey: 'AIzaSyClGYEydkpyELXtuj9fitFjja_87CSc7RY',
  authDomain: 'moindevloperchatapp.firebaseapp.com',
  projectId: 'moindevloperchatapp',
  storageBucket: 'moindevloperchatapp.firebasestorage.app',
  messagingSenderId: '943641273566',
  appId: '1:943641273566:web:96ab98dd651c53d1590e4f',
};

export const app = initializeApp(firebaseConfig);
