import React, { useEffect, useRef, useState } from 'react';
import { app } from './fireBase';
import {
  Box,
  Button,
  Container,
  Input,
  VStack,
  HStack,
} from '@chakra-ui/react';
import Messege from './components/Messege';
import {
  onAuthStateChanged,
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import {
  getFirestore,
  addDoc,
  collection,
  serverTimestamp,
  onSnapshot,
  query,
  orderBy,
} from 'firebase/firestore';

const auth = getAuth(app);

const logInHandler = () => {
  const provider = new GoogleAuthProvider();
  signInWithPopup(auth, provider);
};

const App = () => {
  const [user, setUser] = useState(true);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const db = getFirestore(app);
  const divScroll = useRef(null);

  useEffect(
    () => {
      const q = query(collection(db, 'messages'), orderBy('createdAt', 'asc'));

      const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const messagesArr = [];
        querySnapshot.forEach((doc) => {
          messagesArr.push({ id: doc.id, ...doc.data() });
        });
        setMessages(messagesArr);
      });

      return () => unsubscribe();
    },
    [db],
    [],
  );

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });

    const unSubForMessage = onSnapshot(collection(db, 'messages'), (snap) => {
      setMessages(
        snap.docs.map((item) => {
          const id = item.id;
          return { id, ...item.data() };
        }),
      );
    });
    return () => {
      unsubscribe();
      unSubForMessage();
    };
  }, []);

  const submitHandler = async (e) => {
    e.preventDefault();
    if (!message.trim() || !user) return;

    try {
      await addDoc(collection(db, 'messages'), {
        text: message,
        uid: user.uid,
        photoURL: user.photoURL,
        createdAt: serverTimestamp(),
      });
      setMessage('');
      divScroll.current.scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
      alert('Error sending message: ' + error.message);
    }
  };

  // const logoutHandler = () => {
  //   signOut(auth);
  // };

  return (
    <Box bgColor="red.200">

     {/* {user === "true" || user ? ( */}

        <Container h="100vh" w={'90%'} bgColor="white">
          <VStack h="full" padding={3} css={{"&::-webkit-scrollbar":{
            display:"none"
          }}}>
            <Button w="full" colorScheme="red" onClick={logoutHandler}>
              Log out
            </Button>
            <VStack
              h="full"
              w="full"
              borderRadius="5px"
              overflowY="auto"
              overflowX="hidden"
              spacing={3}
              align="stretch"
            >
              {messages.map((msg) => (
                <Messege
                  key={msg.id}
                  user={msg.uid === user.uid ? 'me' : 'other'}
                  text={msg.text}
                  photoURL={msg.photoURL}
                />
              ))}
              <div ref={divScroll}></div>
            </VStack>
            <form style={{ width: '100%' }} onSubmit={submitHandler}>
              <HStack>
                <Input
                  placeholder="Enter Message"
                  border="1px solid black"
                  borderRadius="10px"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                />
                <Button type="submit" colorScheme="purple" borderRadius="10px">
                  Send
                </Button>
              </HStack>
            </form>
          </VStack>
        </Container>
      {/* )
       : (
        <VStack h="100vh" bgColor="red.100" justifyContent="center">
          <Button onClick={logInHandler} colorScheme="blue" target="_blank">
            Sign in with Google
          </Button>
        </VStack>
      )} */}
    </Box>
  );
};

export default App;
